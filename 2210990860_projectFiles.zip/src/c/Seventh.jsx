import React from "react";

const Seventhpage = () =>{
    return(
        <div className="group-9">
                <div className="text-8">
                <p className="title-13">Nature is above all</p>
                <p className="body-text-12">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                    veniam, quis lorem ipsum dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor
                </p>
                </div>
                <img
                className="place-your-design-here-double-click-to-edit-3"
                src="images/place_your_design_here_do_5.png"
                alt=""
                />
            </div>
    )
}
export default Seventhpage
