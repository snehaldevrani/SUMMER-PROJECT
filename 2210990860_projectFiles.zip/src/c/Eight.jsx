import React from "react";

const Eightpage = () =>{
    return(
        <div className="imsge">
        <div className="text-9">
        <img
            className="title-14"
            src="images/title_8.png"
            alt="Some of our numbers"
            width={296}
            height={23}
            title="Some of our numbers"
        />
        <div className="text-10 match-height group">
            <div className="col-5">
            <p className="body-text-13">Lorem ipsum dolor sit amet consectetur</p>
            <p className="text-11">2018</p>
            <p className="text-12">lorem ipsum</p>
            </div>
            <div className="col-6">
            <p className="body-text-14">Lorem ipsum dolor sit amet consectetur</p>
            <p className="text-13">2019</p>
            <p className="text-14">lorem ipsum</p>
            </div>
            <div className="col-7">
            <p className="body-text-15">Lorem ipsum dolor sit amet consectetur</p>
            <p className="text-15">2020</p>
            <p className="text-16">lorem ipsum</p>
            </div>
        </div>
        </div>
    </div>
    )
}
export default Eightpage