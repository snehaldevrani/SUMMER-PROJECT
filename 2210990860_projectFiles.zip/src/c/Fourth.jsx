import React from "react";

const Fourthpage = () =>{
    return(
        <div className="group-3">
        <div className="l-constrained-3">
        <div className="icons group">
            <img
            className="vector-smart-object-double-click-to-edit-4"
            src="images/vector_smart_object_doubl_3.png"
            alt=""
            width={64}
            height={29}
            />
            <img
            src="images/vector_smart_object_doubl_3.png"
            alt=""
            width={64}
            height={30}
            />
            <img
            className="vector-smart-object-double-click-to-edit-6"
            src="images/vector_smart_object_doubl_3.png"
            alt=""
            width={64}
            height={29}
            />
        </div>
        <div className="text-2 match-height group">
            <div className="col-2">
            <p className="title-5">New music</p>
            <p className="body-text-3">
                Lorem ipsum dolor sit amet, consecte
                <br />
                sectetur adipisicing elit, tation omne
                <br />
                ullamco laboris nisi ut aliqolore.
            </p>
            </div>
            <div className="col-3">
            <p className="title-6">New groups</p>
            <p className="body-text-4">
                Lorem ipsum dolor sit amet, consecte
                <br />
                sectetur adipisicing elit, tation omne
                <br />
                ullamco laboris nisi ut aliqolore.
            </p>
            </div>
            <div className="col-4">
            <p className="title-7">New themes</p>
            <p className="body-text-5">
                Lorem ipsum dolor sit amet, consecte
                <br />
                sectetur adipisicing elit, tation omne
                <br />
                ullamco laboris nisi ut aliqolore.
            </p>
            </div>
        </div>
        </div>
    </div>
    )
}
export default Fourthpage