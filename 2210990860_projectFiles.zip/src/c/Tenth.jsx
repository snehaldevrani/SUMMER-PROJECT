import React from "react";

const Tenthpage = () =>{
    return(
        <div className="group-12">
                <div className="text-17">
                <div className="l-constrained-4 group">
                    <div className="rectangle-7" />
                    <div className="col-15">
                    <p className="title-18" id="contact">Lorem ipsum dolor sit</p>
                    <p className="subtitle-5">Trips / 16th March, 2019</p>
                    </div>
                    <div className="rectangle-8" />
                    <div className="col-16">
                    <p className="title-19">Lorem ipsum dolor sit</p>
                    <p className="subtitle-6">Trips / 16th March, 2019</p>
                    </div>
                    <div className="col-17">
                    <p className="title-20">Lorem ipsum dolor sit</p>
                    <p className="subtitle-7">Trips / 16th March, 2019</p>
                    </div>
                    <div className="rectangle-9" />
                </div>
                </div>
            </div>
    )
}
export default Tenthpage