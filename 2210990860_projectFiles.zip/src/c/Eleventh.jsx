import React from "react";

const Eleventhpage = () =>{
    return(
        <div className="group-13">
                <div className="text-18">
                <p className="text-19">“</p>
                <p className="body-text-19">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                    veniam, quis
                </p>
                <p className="name-5">David Johnson</p>
                </div>
                <div className="social-media-icons group">
                <img
                className="facebook"
                    src="images/f.webp"
                    alt=""
                    width={46}
                    height={46}
                />
                <img
                className="twitter"
                    src="images/twi2.png"
                    alt=""
                    width={46}
                    height={46}
                />
                <img
                className="instagram"
                    src="images/insta.png"
                    alt=""
                    width={46}
                    height={46}
                />
                <img
                className="pinterest"
                    src="images/pinterest.png"
                    alt=""
                    width={46}
                    height={46}
                />
                <img
                className="google"
                    src="images/google.png"
                    alt=""
                    width={46}
                    height={46}
                />
                </div>
            </div>
    )
}
export default Eleventhpage